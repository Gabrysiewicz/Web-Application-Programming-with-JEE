package bp.pai_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaiSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaiSecurityApplication.class, args);
	}

}
