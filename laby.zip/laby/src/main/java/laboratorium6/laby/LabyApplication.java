package laboratorium6.laby;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabyApplication.class, args);
	}

}
