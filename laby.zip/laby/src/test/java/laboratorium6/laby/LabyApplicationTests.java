package laboratorium6.laby;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabyApplicationTests {

	@Test
	void contextLoads() {
	}

}
